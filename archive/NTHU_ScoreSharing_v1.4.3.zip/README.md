# NTHU_ScoreSharing v1.4.3

A browser extension that shares score distributions.
You will be able to see score distributions of curriculums if anyone with this extension has it.  
In return, every class that you have taken will have its score distribution submitted to the shared database.

Available at chrome store: https://chrome.google.com/webstore/detail/nthuscoresharing/fbbgchnopppgncdjbckkjehfchncghdf

## Donation

If this project helped you save your time, you can give us a cup of coffee for our efforts :) 

[![paypal](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.me/b0w1d)
