'use strict'

// const ccxpServer = 'https://www.ccxp.nthu.edu.tw/ccxp/INQUIRE';

async function getTranscript(ccxpToken)
{
    let doc = await getDoc(`${ccxpServer}/JH/8/R/6.3/JH8R63002.php?ACIXSTORE=${ccxpToken}`);
    let dataURI = 'data:text/html;charset=utf8,' + encodeURIComponent(doc.body.innerHTML);
    return dataURI;
}

async function getDistribution(ccxpToken)
{
    let doc = await getDoc(`${ccxpServer}/JH/8/R/6.3/JH8R63002.php?ACIXSTORE=${ccxpToken}`);
    let syllabusLinks = doc.querySelectorAll('a.a');
    let gradeDists = [];

    for (let link of syllabusLinks)
    {
        let params = new URLSearchParams(link.href);
        let c_key = params.get('c_key');
        let c_dist = await getDoc(`${ccxpServer}/JH/8/8.3/8.3.3/JH83302.php?ACIXSTORE=${ccxpToken}&c_key=${c_key}`);
        let dataURI = 'data:text/html;charset=utf8,' + encodeURIComponent(c_dist.body.innerHTML);
        gradeDists.push(dataURI);
    }
    return gradeDists;
}

async function getDoc(URL)
{
    let response = await fetch(URL);
    let buffer = await response.arrayBuffer();

    let decoder = new TextDecoder("big5");
    let text = decoder.decode(buffer);

    let parser = new DOMParser();
    let doc = parser.parseFromString(text, "text/html");
    return doc;
}