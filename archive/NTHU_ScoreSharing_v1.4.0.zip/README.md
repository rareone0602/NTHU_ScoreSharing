# NTHU_ScoreSharing v1.4.0

A browser extension that shares score distributions.
You will be able to see score distributions of curriculums if anyone with this extension has it.  
In return, every class that you have taken will have its score distribution submitted to the shared database.

Available at chrome store: https://chrome.google.com/webstore/detail/nthuscoresharing/fbbgchnopppgncdjbckkjehfchncghdf

## Other Notes
